UI Java Script to give productivity to your code.
The component contains a versatile and easy-to-use image rating, giving dynamism to your application, as well as being able to use it with numbers and letters natively.
Swap Image along with Swap Label makes it easy to replace texts and images without reloading the page.

www.laavor.com
Contact: support@laavor.com