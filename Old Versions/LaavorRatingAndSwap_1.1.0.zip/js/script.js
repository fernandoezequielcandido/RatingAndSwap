function executarImagemSwap(valor, escolha)
{
	alert("Imagem " + valor + ", First ou Second:  " + escolha);
}

function executarNumber(valor)
{
	alert("= " + valor);
}

function executarLetter(valor, escolha)
{
	alert("= " + valor);
}

function executarImage(valor)
{
	alert("= " + valor);
}

function runSwapLabel(valor, firstSecond)
{
	alert("Texto " + valor + ", First ou Second:  " + firstSecond);
}