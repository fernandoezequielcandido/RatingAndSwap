function changeValue(numberValue)
{
	if(numberValue != "0")
	{
		var span = document.getElementById("spanValue");
		span.innerHTML = " value selected is " + numberValue;
	}
	else
	{
		var span = document.getElementById("spanValue");
		span.innerHTML = "";
	}
}

function eventImagemSwap(valueImage, choice)
{
	alert("Image: " + valueImage + ", First or Second-->: -- " + choice + " --");
}

