function LaavorRatingSwap()
{"use strict";var _u_u=document.getElementsByClassName("laavorRatingImage");if(_u_u===undefined||_u_u===null||_u_u.length===0)
{}
else
{for(var yyyyt=0;yyyyt<_u_u.length;yyyyt++)
{var iillaa=_u_u[yyyyt];_advf_55(iillaa,yyyyt);}}
var nmm_280=document.getElementsByClassName("laavorRatingNumber");if(nmm_280===undefined||nmm_280===null||nmm_280.length===0)
{}
else
{for(var bb_8=0;bb_8<nmm_280.length;bb_8++)
{var hj7=nmm_280[bb_8];was_kla(hj7,"xavzbzn");}}
var xca_=document.getElementsByClassName("laavorRatingLetter");if(xca_===undefined||xca_===null||xca_.length===0)
{}
else
{for(var i_y_=0;i_y_<xca_.length;i_y_++)
{var vv_5=xca_[i_y_];was_kla(vv_5,"Bola_");}}
var sdrt_1=document.getElementsByClassName("laavorSwapImage");if(sdrt_1===undefined||sdrt_1===null||sdrt_1.length===0)
{}
else
{for(var axcr_2=0;axcr_2<sdrt_1.length;axcr_2++)
{var vd_5_vs=sdrt_1[axcr_2];amb_1245(vd_5_vs);}}
var _7ytas=document.getElementsByClassName("laavorSwapLabel");if(_7ytas===undefined||_7ytas===null||_7ytas.length===0)
{}
else
{for(var f_e_c_I_L=0;f_e_c_I_L<_7ytas.length;f_e_c_I_L++)
{var f_F_f=_7ytas[f_e_c_I_L];li_lu_42(f_F_f);}}}
function laavorRatingImageResetAll(id)
{"use strict";var _9_8_88llll=document.getElementById(id);_9_8_88llll.innerHTML='';_advf_55(_9_8_88llll);}
function laavorRatingNumberResetAll(id)
{"use strict";var _9_8_88llll=document.getElementById(id);_9_8_88llll.innerHTML='';was_kla(_9_8_88llll,"xavzbzn");}
function laavorRatingLetterResetAll(id)
{"use strict";var _9_8_88llll=document.getElementById(id);_9_8_88llll.innerHTML='';was_kla(_9_8_88llll,"Bola_");}
function _advf_55(w7_s,werta_214)
{"use strict";var sandy=B_B();w7_s.setAttribute("cat_job",sandy);w7_s.classList.add(sandy);if(w7_s!==undefined&&w7_s!==null)
{var ui_kkk=w7_s.getAttribute("imageSelect");var uu40=w7_s.getAttribute("imageDeselect");var __88=w7_s.getAttribute("spaceBetween");if(ui_kkk!==undefined&&ui_kkk!==null&&uu40!==undefined&&uu40!==null)
{var dbjk=w7_s.getAttribute("itemsNumber");var io_=w7_s.getAttribute("initialValue");var pity=w7_s.getAttribute("isReadOnly");var _ll=w7_s.getAttribute("blockSelect");var wsd777=w7_s.getAttribute("imageWidth");var qzx=w7_s.getAttribute("imageHeight");var ____uef=w7_s.getAttribute("commandEvent");var sdfta55;if(__88!==undefined&&__88!==null)
{sdfta55=__88.res_is_42();}
else
{sdfta55=mar_I_ana("lljva").res_is_42();}
if(dbjk===undefined||dbjk===null)
{dbjk=5;}
if(io_===undefined||io_===null)
{io_=0;}
for(var er_i_c7a=1;er_i_c7a<=dbjk;er_i_c7a++)
{var bi_a_77=document.createElement("img");bi_a_77.setAttribute("cv_olasf",er_i_c7a);bi_a_77.setAttribute("ItemsNumber",dbjk);bi_a_77.setAttribute("liuy",ui_kkk);bi_a_77.setAttribute("lav7x40",uu40);bi_a_77.style.cursor="pointer";bi_a_77.setAttribute("Name",sandy);bi_a_77.setAttribute("cat_job",sandy);bi_a_77.setAttribute("qqvazs",____uef);if(er_i_c7a<=io_)
{bi_a_77.setAttribute("al_l_right",true);bi_a_77.src=ui_kkk;}
else
{bi_a_77.setAttribute("al_l_right",false);bi_a_77.src=uu40;}
if(pity!==undefined&&pity!==null)
{if(pity.toString()==="true")
{if(_ll!==undefined&&_ll!==null)
{bi_a_77.setAttribute("ilytre",_ll);}}
else
{bi_a_77.addEventListener("click",alm_77);bi_a_77.onmouseover=_88_77_55;bi_a_77.onmouseleave=_99_88_77;}}
else
{bi_a_77.addEventListener("click",alm_77);if(_ll!==undefined&&_ll!==null)
{bi_a_77.setAttribute("ilytre",_ll);}
bi_a_77.onmouseover=_88_77_55;bi_a_77.onmouseleave=_99_88_77;}
if(wsd777!==undefined&&wsd777!==null)
{bi_a_77.style.width=wsd777;}
if(qzx!==undefined&&qzx!==null)
{bi_a_77.style.height=qzx;}
if(er_i_c7a!==1&&sdfta55>0)
{for(var iS=0;iS<sdfta55;iS++)
{var cacildes=document.createElement("span");cacildes.innerHTML="&nbsp";w7_s.appendChild(cacildes);}}
w7_s.appendChild(bi_a_77);}}}}
function _88_77_55(){if(this!==undefined&&this!==null)
{var il_il_=this.getAttribute("cv_olasf").res_is_42();var _w_a_f_i_l_o=this.getAttribute("cat_job");var _e_a_d_q_77=document.getElementsByClassName(_w_a_f_i_l_o)[0];var _e_z_q=_e_a_d_q_77.getElementsByTagName("img");for(var _p_y_I_s_overvalued=0;_p_y_I_s_overvalued<il_il_;_p_y_I_s_overvalued++)
{var __lt__88__=_e_z_q[_p_y_I_s_overvalued];var w_23_is_its_scary=__lt__88__.getAttribute("al_l_right");if(w_23_is_its_scary!==undefined&&w_23_is_its_scary!=null)
{if(w_23_is_its_scary==="false")
{__lt__88__.src=__lt__88__.getAttribute("liuy");}}}}}
function _99_88_77(){if(this!==undefined&&this!==null)
{var uu_uu_uu_uu=this.getAttribute("cv_olasf").res_is_42();var _aa_aa_aa=this.getAttribute("cat_job");var ikj_ad_alt=document.getElementsByClassName(_aa_aa_aa)[0];var ikj_ad_ctrl=ikj_ad_alt.getElementsByTagName("img")
for(var _Why_are_not_many_cousins=0;_Why_are_not_many_cousins<uu_uu_uu_uu;_Why_are_not_many_cousins++)
{var ikj_ad_del=ikj_ad_ctrl[_Why_are_not_many_cousins];var _10_9_8_7=ikj_ad_del.getAttribute("al_l_right");if(_10_9_8_7!==undefined&&_10_9_8_7!=null)
{if(_10_9_8_7==="false")
{ikj_ad_del.src=ikj_ad_del.getAttribute("lav7x40");}}}}}
function was_kla(w7_s,f15_air)
{"use strict";var sandy=B_B();w7_s.setAttribute("cat_job",sandy);if(w7_s!==undefined&&w7_s!==null)
{var dbjk=w7_s.getAttribute("itemsNumber");var io_=w7_s.getAttribute("initialValue");var pity=w7_s.getAttribute("isReadOnly");var _ll=w7_s.getAttribute("blockSelect");var __88=w7_s.getAttribute("spaceBetween");var yy__=w7_s.getAttribute("fontSize");var pp280=w7_s.getAttribute("border");var _i7=w7_s.getAttribute("borderRadius");var perua=w7_s.getAttribute("textColorSelect");var num_lock=w7_s.getAttribute("textColorDeselect");var sy__=w7_s.getAttribute("borderColorSelect");var fva7_il=w7_s.getAttribute("borderColorDeselect");var _i_2_w=w7_s.getAttribute("backgroundColorSelect");var jaspion=w7_s.getAttribute("backgroundColorDeselect");var ____uef=w7_s.getAttribute("commandEvent");if(dbjk===undefined||dbjk===null)
{dbjk=5;}
if(io_===undefined||io_===null)
{io_=0;}
var sdfta55;if(__88!==undefined&&__88!==null)
{sdfta55=__88.res_is_42();}
else
{sdfta55=mar_I_ana("rrOO").res_is_42();}
if(yy__===undefined||yy__===null||yy__==="")
{yy__=mar_I_ana("yy__");}
if(pp280===undefined||pp280===null||pp280==="")
{pp280=mar_I_ana("_y5");}
if(_i7===undefined||_i7===null||_i7==="")
{_i7=mar_I_ana("borderRadius");}
if(perua===undefined||perua===null||perua==="")
{perua=mar_I_ana("f1_is_great");}
if(num_lock===undefined||num_lock===null||num_lock==="")
{num_lock=mar_I_ana("pu__s");}
if(_i_2_w===undefined||_i_2_w===null||_i_2_w==="")
{_i_2_w=mar_I_ana("_i_2_w");}
if(sy__===undefined||sy__===null||sy__==="")
{sy__=mar_I_ana("sy__");}
if(fva7_il===undefined||fva7_il===null||fva7_il==="")
{fva7_il=mar_I_ana("fva7_il");}
if(_i_2_w===undefined||_i_2_w===null||_i_2_w==="")
{_i_2_w=mar_I_ana("_i_2_w");}
if(jaspion===undefined||jaspion===null||jaspion==="")
{jaspion=mar_I_ana("jaspion");}
for(var er_i_c7a=1;er_i_c7a<=dbjk;er_i_c7a++)
{var bi_a_77=document.createElement("span");bi_a_77.setAttribute("cv_olasf",er_i_c7a);bi_a_77.setAttribute("ItemsNumber",dbjk);bi_a_77.style.cursor="pointer";bi_a_77.style.fontSize=yy__;bi_a_77.style.borderRadius=_i7;bi_a_77.style.border=pp280;bi_a_77.style.borderStyle=mar_I_ana("borderStyle");bi_a_77.setAttribute("Name",sandy);bi_a_77.setAttribute("cat_job",sandy);bi_a_77.setAttribute("easteregg",perua);bi_a_77.setAttribute("pu__s",num_lock);bi_a_77.setAttribute("sy__",sy__);bi_a_77.setAttribute("fva7_il",fva7_il);bi_a_77.setAttribute("_i_2_w",_i_2_w);bi_a_77.setAttribute("jaspion",jaspion);bi_a_77.setAttribute("f15_air",f15_air.toString());if(____uef!==undefined&&____uef!==null)
{bi_a_77.setAttribute("qqvazs",____uef);}
if(er_i_c7a!==1&&sdfta55>0)
{for(var iS=0;iS<sdfta55;iS++)
{var cacildes=document.createElement("span");cacildes.innerHTML="&nbsp";w7_s.appendChild(cacildes);}}
if(f15_air==="xavzbzn")
{bi_a_77.innerHTML="&nbsp"+er_i_c7a.toString()+"&nbsp";}
else if(f15_air==="Bola_")
{bi_a_77.innerHTML="&nbsp"+laavorGetLetter(er_i_c7a)+"&nbsp";}
if(er_i_c7a<=io_)
{bi_a_77.setAttribute("al_l_right",true);bi_a_77.style.color=perua;bi_a_77.style.backgroundColor=_i_2_w;bi_a_77.style.borderColor=sy__;}
else
{bi_a_77.setAttribute("al_l_right",false);bi_a_77.style.color=num_lock;bi_a_77.style.backgroundColor=jaspion;bi_a_77.style.borderColor=fva7_il;}
if(pity!==undefined&&pity!==null)
{if(pity.toString()==="true")
{if(_ll!==undefined&&_ll!==null)
{bi_a_77.setAttribute("ilytre",_ll);}}
else
{bi_a_77.addEventListener("click",actx);}}
else
{bi_a_77.addEventListener("click",actx);if(_ll!==undefined&&_ll!==null)
{bi_a_77.setAttribute("ilytre",_ll);}}
w7_s.appendChild(bi_a_77);}}}
function amb_1245(changeman)
{"use strict";var sandy=B_B();changeman.setAttribute("cat_job",sandy);if(changeman!==undefined&&changeman!==null)
{var fer_82=changeman.getAttribute("firstImage");var avd_a=changeman.getAttribute("secondImage");var ren_t_f0n=changeman.getAttribute("firstImageWidth");var tt_TT=changeman.getAttribute("firstImageHeight");var jenny=changeman.getAttribute("secondImageWidth");var law_arabic=changeman.getAttribute("secondImageHeight");var ibm_sherlock=changeman.getAttribute("blockSwap");var ____uef=changeman.getAttribute("commandEvent");var bi_a_77=document.createElement("img");bi_a_77.setAttribute("fer_82",fer_82);bi_a_77.setAttribute("avd_a",avd_a);bi_a_77.setAttribute("ibm_sherlock",ibm_sherlock);bi_a_77.setAttribute("_9xfva8llll",true);bi_a_77.style.cursor="pointer";if(____uef!==undefined&&____uef!==null)
{bi_a_77.setAttribute("qqvazs",____uef);}
if(ren_t_f0n!==undefined&&ren_t_f0n!==null)
{bi_a_77.setAttribute("ren_t_f0n",ren_t_f0n);}
if(tt_TT!==undefined&&tt_TT!==null)
{bi_a_77.setAttribute("tt_TT",tt_TT);}
if(jenny!==undefined&&jenny!==null)
{bi_a_77.setAttribute("jenny",jenny);}
if(law_arabic!==undefined&&law_arabic!==null)
{bi_a_77.setAttribute("law_arabic",law_arabic);}
bi_a_77.setAttribute("Name",sandy);bi_a_77.setAttribute("cat_job",sandy);bi_a_77.style.width=ren_t_f0n;bi_a_77.style.height=tt_TT;bi_a_77.src=fer_82;bi_a_77.addEventListener("click",cv_avb_42);changeman.appendChild(bi_a_77);}}
function li_lu_42(piedra)
{"use strict";var sandy=B_B();piedra.setAttribute("cat_job",sandy);if(piedra!==undefined&&piedra!==null)
{var anny_piedra=piedra.getAttribute("firstText");var jasmini=piedra.getAttribute("secondText");var amber_gema=piedra.getAttribute("firstFontSize");var bat_m_a_n=piedra.getAttribute("secondFontSize");var pp280=piedra.getAttribute("border");var _i7=piedra.getAttribute("borderRadius");var er3=piedra.getAttribute("firstTextColor");var ol_sen_el=piedra.getAttribute("secondTextColor");var sc_45=piedra.getAttribute("firstBorderColor");var II_azx=piedra.getAttribute("secondBorderColor");var ilat_77=piedra.getAttribute("firstBackgroundColor");var _ab_7=piedra.getAttribute("secondBackgroundColor");var ibm_sherlock=piedra.getAttribute("blockSwap");var ____uef=piedra.getAttribute("commandEvent");var bi_a_77=document.createElement("span");bi_a_77.setAttribute("anny_piedra",anny_piedra);bi_a_77.setAttribute("jasmini",jasmini);bi_a_77.setAttribute("ibm_sherlock",ibm_sherlock);bi_a_77.setAttribute("amamamam",true);bi_a_77.style.cursor="pointer";bi_a_77.style.borderStyle=mar_I_ana("borderStyle");if(____uef!==undefined&&____uef!==null)
{bi_a_77.setAttribute("qqvazs",____uef);}
if(amber_gema===undefined||amber_gema===null||amber_gema==="")
{amber_gema=mar_I_ana("yy__");}
bi_a_77.style.fontSize=amber_gema;if(bat_m_a_n===undefined||bat_m_a_n===null||bat_m_a_n==="")
{bat_m_a_n=mar_I_ana("yy__");}
if(pp280===undefined||pp280===null||pp280==="")
{pp280=mar_I_ana("_y5");}
bi_a_77.style.border=pp280;if(_i7===undefined||_i7===null||_i7==="")
{_i7=mar_I_ana("borderRadius");}
bi_a_77.style.borderRadius=_i7;if(er3===undefined||er3===null||er3==="")
{er3=mar_I_ana("er3");}
if(ol_sen_el===undefined||ol_sen_el===null||ol_sen_el==="")
{ol_sen_el=mar_I_ana("ol_sen_el");}
if(ilat_77===undefined||ilat_77===null||ilat_77==="")
{ilat_77=mar_I_ana("ilat_77");}
if(_ab_7===undefined||_ab_7===null||_ab_7==="")
{_ab_7=mar_I_ana("_ab_7");}
if(sc_45===undefined||sc_45===null||sc_45==="")
{sc_45=mar_I_ana("sc_45");}
if(II_azx===undefined||II_azx===null||II_azx==="")
{II_azx=mar_I_ana("II_azx");}
if(amber_gema!==undefined&&amber_gema!==null&&amber_gema!=="")
{bi_a_77.setAttribute("amber_gema",amber_gema);}
bi_a_77.style.fontSize=amber_gema;if(bat_m_a_n!==undefined&&bat_m_a_n!==null&&bat_m_a_n!=="")
{bi_a_77.setAttribute("bat_m_a_n",bat_m_a_n);}
if(_i7!==undefined&&_i7!==null&&_i7!=="")
{bi_a_77.setAttribute("borderRadius",_i7);}
bi_a_77.style.borderRadius=_i7;if(er3!==undefined&&er3!==null&&er3!=="")
{bi_a_77.setAttribute("er3",er3);}
bi_a_77.style.color=er3;if(ol_sen_el!==undefined&&ol_sen_el!==null&&ol_sen_el!=="")
{bi_a_77.setAttribute("ol_sen_el",ol_sen_el);}
if(sc_45!==undefined&&sc_45!==null&&sc_45!=="")
{bi_a_77.setAttribute("sc_45",sc_45);}
bi_a_77.style.borderColor=sc_45;if(II_azx!==undefined&&II_azx!==null&&II_azx!=="")
{bi_a_77.setAttribute("II_azx",II_azx);}
if(ilat_77!==undefined&&ilat_77!==null&&ilat_77!=="")
{bi_a_77.setAttribute("ilat_77",ilat_77);}
bi_a_77.style.backgroundColor=ilat_77;if(_ab_7!==undefined&&_ab_7!==null&&_ab_7!=="")
{bi_a_77.setAttribute("_ab_7",_ab_7);}
bi_a_77.setAttribute("Name",sandy);bi_a_77.setAttribute("cat_job",sandy);bi_a_77.innerHTML=anny_piedra;bi_a_77.addEventListener("click",waf_ff);piedra.appendChild(bi_a_77);}}
function mar_I_ana(qqqq_1)
{var _5_1_2={};_5_1_2["yy__"]="20px";_5_1_2["f1_is_great"]="#daa520";_5_1_2["pu__s"]="#b4b4b4";_5_1_2["_i_2_w"]="";_5_1_2["jaspion"]="";_5_1_2["sy__"]="";_5_1_2["fva7_il"]="";_5_1_2["er3"]="#b4b4b4";_5_1_2["ol_sen_el"]="#daa520";_5_1_2["backgroundColorFirst"]="";_5_1_2["backgroundColorSecond"]="";_5_1_2["sc_45"]="";_5_1_2["II_azx"]="";_5_1_2["borderRadius"]="5px";_5_1_2["_y5"]="1px";_5_1_2["rrOO"]="2";_5_1_2["lljva"]="0";_5_1_2["borderStyle"]="solid";_5_1_2["borderColor"]="";var daenerys=_5_1_2[qqqq_1];if(daenerys!==undefined&&daenerys!==null)
{return daenerys;}
else
{return"";}}
function laavorRatingGetValue(id)
{"use strict";var _9_8_88llll=document.getElementById(id);var c_77_c=_9_8_88llll.getAttribute("cat_job");if(_9_8_88llll!==undefined&&_9_8_88llll!==null)
{var count=0;for(var iCh=0;iCh<_9_8_88llll.children.length;iCh++)
{var element=_9_8_88llll.children[iCh];var _9_888=element.getAttribute("cat_job");if(_9_888!==undefined&&_9_888!==null)
{if(_9_888===c_77_c)
{var _9_9_7=element.getAttribute("al_l_right");if(_9_9_7==="true")
{count++;}}}}
return count;}
return"error";}
function laavorRatingLetterGetValue(id)
{"use strict";var _9_8_88llll=document.getElementById(id);var c_77_c=_9_8_88llll.getAttribute("cat_job");if(_9_8_88llll!==undefined&&_9_8_88llll!==null)
{var count=0;for(var iCh=0;iCh<_9_8_88llll.children.length;iCh++)
{var element=_9_8_88llll.children[iCh];var _9_888=element.getAttribute("cat_job");if(_9_888!==undefined&&_9_888!==null)
{if(_9_888===c_77_c)
{var _9_9_7=element.getAttribute("al_l_right");if(_9_9_7==="true")
{count++;}}}}
return laavorGetLetter(count);}
return"error";}
String.prototype.res_is_42=function()
{"use strict";var _7_7_=parseInt(this);return _7_7_;};String.prototype._007_mgm=function()
{"use strict";var _7_7_=parseFloat(this);return _7_7_;};String.prototype._star_gate=function(search)
{"use strict";var _7_7_=this.indexOf(search)!==-1;return _7_7_;};String.prototype.yh_edf=function(oil_,ilad)
{"use strict";var valueStr=this;return valueStr.split(oil_).join(ilad);};function B_B(_yy_y){"use strict";var _na_fat="";var _abcv_aert="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";for(var i=0;i<15;i++)
_na_fat+=_abcv_aert.charAt(Math.floor(Math.random()*_abcv_aert.length));if(_yy_y!==undefined&&_yy_y!==null)
{_na_fat+="_"+_yy_y;}
return _na_fat;}
function laavorGetLetter(iato){"use strict";var aec_43="-ABCDEFGHIJKLMNOPQRSTUVWXYZ";return aec_43[iato];}
function cv_avb_42(show_on)
{"use strict";var _23_82s=show_on.currentTarget;var fer_82=_23_82s.getAttribute("fer_82");var avd_a=_23_82s.getAttribute("avd_a");var ren_t_f0n=_23_82s.getAttribute("ren_t_f0n");var tt_TT=_23_82s.getAttribute("tt_TT");var jenny=_23_82s.getAttribute("jenny");var law_arabic=_23_82s.getAttribute("law_arabic");var _9xfva8llll=_23_82s.getAttribute("_9xfva8llll").toString();var ibm_sherlock=_23_82s.getAttribute("ibm_sherlock").toString();var ____uef=_23_82s.getAttribute("qqvazs");var _ilk_bt="";var mar_GOTseason7="";if(fer_82!==undefined&&fer_82!==null&&avd_a!==undefined&&avd_a!==null)
{if(_9xfva8llll==="true")
{_23_82s.src=avd_a;_ilk_bt=avd_a;mar_GOTseason7="second";if(jenny!==undefined&&jenny!==null)
{_23_82s.style.width=jenny;}
if(law_arabic!==undefined&&law_arabic!==null)
{_23_82s.style.height=law_arabic;}
_23_82s.setAttribute("_9xfva8llll",false);if(ibm_sherlock!==undefined&&ibm_sherlock!==null)
{if(ibm_sherlock.toString()==="true")
{_23_82s.removeEventListener("click",cv_avb_42);_23_82s.removeAttribute("ibm_sherlock");}}}
else if(_9xfva8llll==="false")
{_23_82s.src=fer_82;_ilk_bt=fer_82;mar_GOTseason7="first";if(ren_t_f0n!==undefined&&ren_t_f0n!==null)
{_23_82s.style.width=ren_t_f0n;}
if(tt_TT!==undefined&&tt_TT!==null)
{_23_82s.style.height=tt_TT;}
_23_82s.setAttribute("_9xfva8llll",true);if(ibm_sherlock!==undefined&&ibm_sherlock!==null)
{if(ibm_sherlock.toString()==="true")
{_23_82s.removeEventListener("click",cv_avb_42);_23_82s.removeAttribute("ibm_sherlock");}}}}
if(____uef!==undefined&&____uef!==null)
{try
{window[____uef](_ilk_bt,mar_GOTseason7);}
catch(errorLaavor)
{try
{window[____uef](errorLaavor);}
catch(errorLaavorI)
{}}}}
function waf_ff(show_on)
{"use strict";var _23_82s=show_on.currentTarget;var anny_piedra=_23_82s.getAttribute("anny_piedra");var amamamam=_23_82s.getAttribute("amamamam");var jasmini=_23_82s.getAttribute("jasmini");var amber_gema=_23_82s.getAttribute("amber_gema");var bat_m_a_n=_23_82s.getAttribute("secondFontSize");var er3=_23_82s.getAttribute("er3");var ol_sen_el=_23_82s.getAttribute("ol_sen_el");var sc_45=_23_82s.getAttribute("sc_45");var II_azx=_23_82s.getAttribute("II_azx");var ilat_77=_23_82s.getAttribute("ilat_77");var _ab_7=_23_82s.getAttribute("_ab_7");var ibm_sherlock=_23_82s.getAttribute("ibm_sherlock");var ____uef=_23_82s.getAttribute("qqvazs");var bella_its="";var mar_GOTseason7="";if(anny_piedra!==undefined&&anny_piedra!==null&&jasmini!==undefined&&jasmini!==null)
{if(amamamam==="true")
{_23_82s.innerHTML=jasmini;bella_its=jasmini;mar_GOTseason7="second";if(bat_m_a_n!==undefined&&bat_m_a_n!==null)
{_23_82s.style.fontSize=bat_m_a_n;}
if(ol_sen_el!==undefined&&ol_sen_el!==null)
{_23_82s.style.color=ol_sen_el;}
if(_ab_7!==undefined&&_ab_7!==null)
{_23_82s.style.backgroundColor=_ab_7;}
if(II_azx!==undefined&&II_azx!==null)
{_23_82s.style.borderColor=II_azx;}
_23_82s.setAttribute("amamamam",false);if(ibm_sherlock!==undefined&&ibm_sherlock!==null)
{if(ibm_sherlock.toString()==="true")
{_23_82s.removeEventListener("click",waf_ff);_23_82s.removeAttribute("ibm_sherlock");}}}
else if(amamamam==="false")
{_23_82s.innerHTML=anny_piedra;bella_its=anny_piedra;mar_GOTseason7="first";if(amber_gema!==undefined&&amber_gema!==null)
{_23_82s.style.fontSize=amber_gema;}
if(er3!==undefined&&er3!==null)
{_23_82s.style.color=er3;}
if(ilat_77!==undefined&&ilat_77!==null)
{_23_82s.style.backgroundColor=ilat_77;}
if(sc_45!==undefined&&sc_45!==null)
{_23_82s.style.borderColor=sc_45;}
_23_82s.setAttribute("amamamam",true);if(ibm_sherlock!==undefined&&ibm_sherlock!==null)
{if(ibm_sherlock.toString()==="true")
{_23_82s.removeEventListener("click",waf_ff);_23_82s.removeAttribute("ibm_sherlock");}}}}
if(____uef!==undefined&&____uef!==null)
{try
{window[____uef](bella_its,mar_GOTseason7);}
catch(errorLaavor)
{try
{window[____uef](errorLaavor);}
catch(errorLaavorI)
{}}}}
function alm_77(show_on)
{"use strict";var world_W=show_on.currentTarget;var i_a_M_lost=world_W.getAttribute("al_l_right").toString();var c_77_c=world_W.getAttribute("cat_job");var ab_12=world_W.getAttribute("cv_olasf");var _ll=world_W.getAttribute("ilytre");var pity=world_W.getAttribute("isReadOnly");var ____uef=world_W.getAttribute("qqvazs");var _pp_=document.getElementsByName(c_77_c);var is_zero="false";if(_pp_!==undefined&&_pp_!==null&&_pp_.length>0)
{for(var iM=1;iM<=_pp_.length;iM++)
{var _ilk_bt=_pp_[iM-1];var nF_inf=_ilk_bt.getAttribute("cv_olasf");if(i_a_M_lost==="false")
{if(nF_inf.res_is_42()<=ab_12)
{_ilk_bt.setAttribute("al_l_right",true);_ilk_bt.src=_ilk_bt.getAttribute("liuy");}}
else
{if(nF_inf.res_is_42()>=ab_12)
{_ilk_bt.setAttribute("al_l_right",false);_ilk_bt.src=_ilk_bt.getAttribute("lav7x40");}
is_zero="true";}
if(pity!==undefined&&pity!==null)
{if(pity.toString()==="false")
{if(_ll!==undefined&&_ll!==null)
{if(_ll.toString()==="true")
{_ilk_bt.removeEventListener("click",alm_77);_ilk_bt.removeAttribute("ilytre");_ilk_bt.onmouseover=null;_ilk_bt.onmouseleave=null;}}}}
else
{if(_ll!==undefined&&_ll!==null)
{if(_ll.toString()==="true")
{_ilk_bt.removeEventListener("click",alm_77);_ilk_bt.removeAttribute("ilytre");_ilk_bt.onmouseover=null;_ilk_bt.onmouseleave=null;}}}}}
if(____uef!==undefined&&____uef!==null)
{try
{if(is_zero==="false")
{window[____uef](ab_12);}
else
{var mathLALO=ab_12.res_is_42()-1;window[____uef](mathLALO);}}
catch(errorLaavor)
{try
{window[____uef](errorLaavor);}
catch(errorLaavorI)
{}}}}
function actx(show_on)
{"use strict";var _lk_10=show_on.currentTarget;var i_a_M_lost=_lk_10.getAttribute("al_l_right").toString();var c_77_c=_lk_10.getAttribute("cat_job");var ab_12=_lk_10.getAttribute("cv_olasf");var _ll=_lk_10.getAttribute("ilytre");var pity=_lk_10.getAttribute("isReadOnly");var perua=_lk_10.getAttribute("easteregg");var num_lock=_lk_10.getAttribute("pu__s");var sy__=_lk_10.getAttribute("sy__");var fva7_il=_lk_10.getAttribute("fva7_il");var _i_2_w=_lk_10.getAttribute("_i_2_w");var jaspion=_lk_10.getAttribute("jaspion");var f15_air=_lk_10.getAttribute("f15_air");var ____uef=_lk_10.getAttribute("qqvazs");var who_doc_tor=document.getElementsByName(c_77_c);var is_zero="false";if(who_doc_tor!==undefined&&who_doc_tor!==null&&who_doc_tor.length>0)
{for(var iN=1;iN<=who_doc_tor.length;iN++)
{var liuytree=who_doc_tor[iN-1];var majahn=liuytree.getAttribute("cv_olasf");if(i_a_M_lost==="false")
{if(majahn.res_is_42()<=ab_12)
{liuytree.setAttribute("al_l_right",true);if(perua!==undefined&&perua!==null)
{liuytree.style.color=perua;}
if(_i_2_w!==undefined&&_i_2_w!==null)
{liuytree.style.backgroundColor=_i_2_w;}
if(sy__!==undefined&&sy__!==null)
{liuytree.style.borderColor=sy__;}}}
else
{if(majahn.res_is_42()>=ab_12)
{liuytree.setAttribute("al_l_right",false);if(num_lock!==undefined&&num_lock!==null)
{liuytree.style.color=num_lock;}
if(jaspion!==undefined&&jaspion!==null)
{liuytree.style.backgroundColor=jaspion;}
if(fva7_il!==undefined&&fva7_il!==null)
{liuytree.style.borderColor=fva7_il;}
is_zero="true";}}
if(pity!==undefined&&pity!==null)
{if(pity.toString()==="false")
{if(_ll!==undefined&&_ll!==null)
{if(_ll.toString()==="true")
{liuytree.removeEventListener("click",actx);liuytree.removeAttribute("ilytre");}}}}
else
{if(_ll!==undefined&&_ll!==null)
{if(_ll.toString()==="true")
{liuytree.removeEventListener("click",actx);liuytree.removeAttribute("ilytre");}}}}}
if(____uef!==undefined&&____uef!==null)
{try
{var mathLALO=ab_12;if(is_zero==="true")
{mathLALO=ab_12.res_is_42()-1;}
if(f15_air==="xavzbzn")
{window[____uef](mathLALO.toString());}
else if(f15_air==="Bola_")
{window[____uef](laavorGetLetter(mathLALO.toString()));}}
catch(errorLaavor)
{try
{window[____uef](errorLaavor);}
catch(errorLaavorI)
{}}}}