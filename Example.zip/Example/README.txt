UI Java Script to give productivity to your code.

www.laavor.com

Fernando E. Candido
Contact: candido@laavor.com

OBS: It is not necessary to use JQuery.